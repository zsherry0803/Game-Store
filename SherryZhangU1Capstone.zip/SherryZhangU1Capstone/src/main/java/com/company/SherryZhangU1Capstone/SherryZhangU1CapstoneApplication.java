package com.company.SherryZhangU1Capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SherryZhangU1CapstoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SherryZhangU1CapstoneApplication.class, args);
	}

}
