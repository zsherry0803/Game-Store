package com.company.SherryZhangU1Capstone.dao;

import com.company.SherryZhangU1Capstone.model.SalesTaxRate;

public interface SalesTaxRateDao {
    SalesTaxRate getSalesTaxRate(int ix);
}
