package com.company.SherryZhangU1Capstone.dao;

import com.company.SherryZhangU1Capstone.model.ProcessingFee;

public interface ProcessingFeeDao {
    ProcessingFee getProcessingFee(String productType);
}
